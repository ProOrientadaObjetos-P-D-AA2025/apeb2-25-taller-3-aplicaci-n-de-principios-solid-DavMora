
package p3;

import p1.*;
import p2.TipoMatricula;
import java.util.ArrayList;

public class Principal {
    public static void main(String[] args) {
        ArrayList<Matricula> listaMatriculas = new ArrayList<>();

        MatriculaCampamento matriculaCampamento = new MatriculaCampamento();
        matriculaCampamento.establecerTarifa();

        MatriculaColegio matriculaColegio = new MatriculaColegio();
        matriculaColegio.establecerTarifa();

        MatriculaEscuela matriculaEscuela = new MatriculaEscuela();
        matriculaEscuela.establecerTarifa();

        MatriculaJardin matriculaJardin = new MatriculaJardin();
        matriculaJardin.establecerTarifa();

        MatriculaMaternal matriculaMaternal = new MatriculaMaternal();
        matriculaMaternal.establecerTarifa();

        listaMatriculas.add(matriculaCampamento);
        listaMatriculas.add(matriculaColegio);
        listaMatriculas.add(matriculaEscuela);
        listaMatriculas.add(matriculaJardin);
        listaMatriculas.add(matriculaMaternal);

        TipoMatricula tipoMatricula = new TipoMatricula();
        tipoMatricula.establecerListaMatriculas(listaMatriculas);
        tipoMatricula.establecerPromedioTarifas();

        System.out.println(tipoMatricula);
    }
}


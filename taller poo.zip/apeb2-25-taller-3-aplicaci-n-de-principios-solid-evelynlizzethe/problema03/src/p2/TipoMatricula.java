package p2;

import p1.Matricula;
import java.util.ArrayList;

public class TipoMatricula {
    private double promedioMatriculas;
    private ArrayList<Matricula> listaMatriculas;

    public void establecerListaMatriculas(ArrayList<Matricula> lista) {
        listaMatriculas = lista;
    }

    public ArrayList<Matricula> obtenerListaMatriculas() {
        return listaMatriculas;
    }

    public void establecerPromedioTarifas() {
        double suma = 0;
        for (Matricula m : listaMatriculas) {
            suma += m.obtenerTarifa();
        }
        promedioMatriculas = suma / listaMatriculas.size();
    }

    public double obtenerPromedioTarifas() {
        return promedioMatriculas;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Detalles de las matriculas:\n");
        for (Matricula m : listaMatriculas) {
            sb.append(String.format("- Tarifa: %.2f\n", m.obtenerTarifa()));
        }
        sb.append(String.format("Promedio total: %.2f", obtenerPromedioTarifas()));
        return sb.toString();
    }
}

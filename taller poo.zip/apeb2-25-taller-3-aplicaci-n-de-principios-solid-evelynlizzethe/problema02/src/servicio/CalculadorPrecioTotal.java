
package servicio;

import java.util.ArrayList;
import paquete01.Televisor;

public class CalculadorPrecioTotal {
    public static double calcular(ArrayList<Televisor> tvs) {
        double total = 0;
        for (int i = 0; i < tvs.size(); i++) {
            total += tvs.get(i).obtenerPrecio();
        }
        return total;
    }
}

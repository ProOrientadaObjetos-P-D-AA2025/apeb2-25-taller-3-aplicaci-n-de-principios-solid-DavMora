
package servicio;

import java.util.ArrayList;
import paquete01.Televisor;

public class GeneradorMarcas {
    public static String generar(ArrayList<Televisor> tvs) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tvs.size(); i++) {
            sb.append(tvs.get(i).obtenerMarca()).append("\n");
        }
        return sb.toString();
    }
}

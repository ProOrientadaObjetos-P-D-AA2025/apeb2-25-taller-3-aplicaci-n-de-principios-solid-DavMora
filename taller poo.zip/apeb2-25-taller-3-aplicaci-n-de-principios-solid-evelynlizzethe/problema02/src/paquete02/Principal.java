
package paquete02;

import java.util.ArrayList;
import paquete01.Televisor;
import paquete03.VentasTvs;
import servicio.CalculadorPrecioTotal;
import servicio.GeneradorMarcas;

/**
 *
 * @author reroes
 */

public class Principal {
    public static void main(String[] args) {
        Televisor t1 = new Televisor();
        t1.establecerMarca("LG - 14 pulgadas");
        t1.establecerPrecio(300.2);

        Televisor t2 = new Televisor();
        t2.establecerMarca("SAMSUNG - 21 pulgadas");
        t2.establecerPrecio(1300.2);

        Televisor t3 = new Televisor();
        t3.establecerMarca("RIVIERA - 29 pulgadas");
        t3.establecerPrecio(2300.5);

        ArrayList<Televisor> listaTvs = new ArrayList<>();
        listaTvs.add(t1);
        listaTvs.add(t2);
        listaTvs.add(t3);

        VentasTvs venta = new VentasTvs();
        venta.establecerTelevisores(listaTvs);

        double total = CalculadorPrecioTotal.calcular(venta.obtenerTelevisores());
        String marcas = GeneradorMarcas.generar(venta.obtenerTelevisores());

        System.out.println("---------- VENTA DE TELEVISIORES ----------");
        System.out.printf("Precio total: %.2f\n", total);
        System.out.println("Marcas vendidas:\n" + marcas);
    }
}
